<?php print_r($_POST); 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";
$rackno = $_POST['rackno'];
$palletno = $_POST['palletno'];
$sapcode = $_POST['sapcode'];
$gkcode = $_POST['gkcode'];
$desc =  $_POST['description'];
$oum = $_POST['uom'];
$qty = $_POST['qty'];
$sapstock = $_POST['sapstock'];
$remark = $_POST['remark'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// echo "INSERT INTO inventory (rackno, palletno, sapcode, gkcode, description, uom, qty, sapstock, remark)
// VALUES ('$rackno', '$palletno', '$sapcode', '$gkcode', '$desc', '$oum', '$qty', '$sapstock', '$remark')"; die;
$sql = "INSERT INTO inventory (rackno, palletno, sapcode, gkcode, description, uom, qty, sapstock, remark)
VALUES ('$rackno', '$palletno', '$sapcode', '$gkcode', '$desc', '$oum', '$qty', '$sapstock', '$remark')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
 ?>