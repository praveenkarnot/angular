<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Inventory</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom fonts for this template -->
        <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="vendor/simple-line-icons/css/simple-line-icons.css">
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

        <!-- Plugin CSS -->
        <link rel="stylesheet" href="device-mockups/device-mockups.min.css">

        <!-- Custom styles for this template -->
        <link href="css/new-age.min.css" rel="stylesheet">
        <style> 
input[type=text] {
    width: 130px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
    width: 100%;
}
</style>
    </head>

    <body id="page-top">

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top">Start Bootstrap</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fa fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link js-scroll-trigger" href="#download">Download</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link js-scroll-trigger" href="#features">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <section class="features" id="features">
            <div class="container">
            <form action="" method="GET">
        <input type="text" name="search" placeholder="Search..">
        <!-- <input type="submit" name="submit" value="Search" /> -->
    </form>
            
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "inventory";
                    
                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    
                    if(isset($_GET['search'])){
                        $query=$_GET['search'];
                        $sql = "SELECT * FROM inventory where sapcode = '$query'"; // die;
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                      echo '<table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Rack No</th>
                                <th>Pallet No</th>
                                <th>SAP Code</th>
                                <th>GK Code</th>
                                <th>Description</th>
                                <th>Uom</th>
                                <th>Quantity</th>
                                <th>sap stock</th>
                                <th>REMARKS</th>
                              </tr>
                            </thead><tbody>';
                            while($row = $result->fetch_assoc()) {
                                // echo '<li class="list-group-item">'.$row["rackno"].'</li>';
                                echo '<tr>
                                <td>'.$row["rackno"].'</td>
                                <td>'.$row["palletno"].'</td>
                                <td>'.$row["sapcode"].'</td>
                                <td>'.$row["gkcode"].'</td>
                                <td>'.$row["description"].'</td>
                                <td>'.$row["uom"].'</td>
                                <td>'.$row["qty"].'</td>
                                <td>'.$row["sapstock"].'</td>
                                <td>'.$row["remark"].'</td>
                              </tr>';
                            }
                        }
                        else {
                            echo "No data found";
                        }
                      }
                      else {

                        $sql = "SELECT * FROM inventory";
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            echo '<table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Rack No</th>
                                <th>Pallet No</th>
                                <th>SAP Code</th>
                                <th>GK Code</th>
                                <th>Description</th>
                                <th>Uom</th>
                                <th>Quantity</th>
                                <th>sap stock</th>
                                <th>REMARKS</th>
                              </tr>
                            </thead><tbody>';
                            while($row = $result->fetch_assoc()) {
                                // echo '<li class="list-group-item">'.$row["rackno"].'</li>';
                                echo '<tr>
                                <td>'.$row["rackno"].'</td>
                                <td>'.$row["palletno"].'</td>
                                <td>'.$row["sapcode"].'</td>
                                <td>'.$row["gkcode"].'</td>
                                <td>'.$row["description"].'</td>
                                <td>'.$row["uom"].'</td>
                                <td>'.$row["qty"].'</td>
                                <td>'.$row["sapstock"].'</td>
                                <td>'.$row["remark"].'</td>
                              </tr>';
                            }
                        }
                      }
                     
                    $conn->close();
                    ?>

    </tbody>
  </table>
                

            </div>
        </section>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for this template -->
        <script src="js/new-age.min.js"></script>

    </body>

</html>